// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception.
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "A custom application exception occurred.";
    }
};

bool do_even_more_custom_application_logic()
{
    // Throw a standard C++ exception.
    throw std::runtime_error("Error in Even More Custom Application Logic.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    // Wrap the call with a try/catch block that catches std::exception.
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& exception)
    {
        std::cout << "Standard exception caught: "
            << exception.what() << std::endl;
    }

    // Throw a custom exception derived from std::exception.
    // This exception is caught explicitly in main.
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Throw a standard C++ exception for division by zero.
    if (den == 0)
    {
        throw std::invalid_argument("Cannot divide by zero.");
    }

    return (num / den);
}

void do_division() noexcept
{
    // Catch only the exception type thrown by divide.
    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);

        std::cout << "divide(" << numerator << ", "
            << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& exception)
    {
        std::cout << "Division exception caught: "
            << exception.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Catch the custom exception first, then std::exception,
    // followed by a catch-all handler for any other exception.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& exception)
    {
        std::cout << "Custom exception caught: "
            << exception.what() << std::endl;
    }
    catch (const std::exception& exception)
    {
        std::cout << "Standard exception caught in main: "
            << exception.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "An unknown exception was caught." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu