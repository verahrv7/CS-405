// Encryption.cpp : This file contains the 'main' function.
// Program execution begins and ends there.

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// Encrypt or decrypt a source string using the provided key.
/// </summary>
/// <param name="source">Input string to process</param>
/// <param name="key">Key to use in encryption / decryption</param>
/// <returns>Transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // Get lengths now instead of calling the function every time.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Make sure the input data is valid.
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Loop through the source string character by character.
    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR each character with a character from the key.
        // Modulo starts the key over when the end of the key is reached.
        output[i] = source[i] ^ key[i % key_length];
    }

    // The output length must equal the source length.
    assert(output.length() == source_length);

    return output;
}

std::string read_file(const std::string& filename)
{
    // Open the input file.
    std::ifstream input_file(filename, std::ios::binary);

    // Check that the file opened successfully.
    if (!input_file)
    {
        std::cerr << "Unable to open file: " << filename << std::endl;
        return "";
    }

    // Read the entire file into a string.
    std::stringstream buffer;
    buffer << input_file.rdbuf();

    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline.
    size_t pos = string_data.find('\n');

    // If a newline was found, copy the first line as the student name.
    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(
    const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    // Open the output file in binary mode so encrypted data is saved correctly.
    std::ofstream output_file(filename, std::ios::binary);

    // Check that the file opened successfully.
    if (!output_file)
    {
        std::cerr << "Unable to save file: " << filename << std::endl;
        return;
    }

    // Get the current date.
    std::time_t current_time = std::time(nullptr);
    std::tm local_time{};

    localtime_s(&local_time, &current_time);

    // Required output file format:
    // Line 1: student name
    // Line 2: timestamp (yyyy-mm-dd)
    // Line 3: key used
    // Line 4+: data
    output_file << student_name << '\n';
    output_file << std::put_time(&local_time, "%Y-%m-%d") << '\n';
    output_file << key << '\n';

    // Write all data, including encrypted characters.
    output_file.write(data.data(), data.size());

    output_file.close();
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    // Input file format:
    // Line 1: Student name
    // Line 2: Lorem Ipsum Generator website used
    // Lines 3+: Three paragraphs of generated text

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt";

    // Read the original data file.
    const std::string source_string = read_file(file_name);

    // Stop if the input file could not be loaded.
    if (source_string.empty())
    {
        std::cerr << "No input data was loaded." << std::endl;
        return 1;
    }

    // Encryption key.
    const std::string key = "password";

    // Get the student name from the data file.
    const std::string student_name = get_student_name(source_string);

    // Encrypt the original data.
    const std::string encrypted_string =
        encrypt_decrypt(source_string, key);

    // Save the encrypted data.
    save_data_file(
        encrypted_file_name,
        student_name,
        key,
        encrypted_string);

    // XOR the encrypted data with the same key to decrypt it.
    const std::string decrypted_string =
        encrypt_decrypt(encrypted_string, key);

    // Save the decrypted data.
    save_data_file(
        decrypted_file_name,
        student_name,
        key,
        decrypted_string);

    std::cout
        << "Read File: " << file_name
        << " - Encrypted To: " << encrypted_file_name
        << " - Decrypted To: " << decrypted_file_name
        << std::endl;

    return 0;
}